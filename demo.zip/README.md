# Maths-Easy
App is developed as a part of a series depicting Android App creation with the help of Framework7 &amp; Cordova.
For the tuorial Visit http://alapan.me

# Tutorial Links
[Part 1](http://www.alapan.me/first-android-app-framework7-cordova-part1/) | [Part 2](http://www.alapan.me/first-android-app-framework7-cordova-part2/) 

# App Demo
![Maths Easy App](http://postmyimage.com/img2/400_Maths_Easy_GIF.gif)
